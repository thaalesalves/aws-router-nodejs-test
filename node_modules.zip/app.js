const AWSLambdaRouter = require('aws-lambda-router-wn');
const axios = require('axios');
const app = new AWSLambdaRouter();

app.post('/', async (request, response) => {
  let resBody;
  const reqBody = request.body;
  if (typeof reqBody.language == 'undefined') {
    resBody = "Nada aqui";
  } else if (reqBody.language == 'fr') {
    async () => {
      try {
        const res = await axios.get('https://fathomless-island-76403.herokuapp.com/api');
        resbody = res.data;
        console.log(JSON.stringify(res))
        console.log(JSON.stringify(res.data))
      } catch (err) {
        resBody = "Erro ao fazer chamada"
      }
    }
  } else if (reqBody.language == 'pt') {
    async () => {
      try {
        const res = await axios.get('https://fathomless-island-76402.herokuapp.com/api');
        resbody = res.data;
        console.log(JSON.stringify(res))
        console.log(JSON.stringify(res.data))
      } catch (err) {
        resBody = "Erro ao fazer chamada"
      }
    }
  }

  if (typeof resBody == 'undefined') {
    resBody = "Empty body"
  }

  response(null, { text: JSON.stringify(resBody) });
}, {
  bodyType: 'application/json'
});

exports.handler = (event, context, callback) => {
  app.serve(event, callback);
};